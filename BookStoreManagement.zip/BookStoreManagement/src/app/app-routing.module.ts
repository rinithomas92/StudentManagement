import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGaurdService } from './auth-gaurd.service';
import { BooklistComponent } from './component/booklist/booklist.component';
import { LoginComponent } from './component/login/login.component';
import { LogoutComponent } from './component/logout/logout.component';
import { MainComponent } from './component/main/main.component';
import { RegisterComponent } from './component/register/register.component';

const routes: Routes = [  
  {path: '', component: MainComponent },
  { path: 'main', component: MainComponent },
  { path: 'register', component: RegisterComponent ,canActivate:[AuthGaurdService]},
  {path:'booklist',component: BooklistComponent},
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent,canActivate:[AuthGaurdService] },

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
