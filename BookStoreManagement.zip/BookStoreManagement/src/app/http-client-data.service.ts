import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { BooksDto } from './model/BooksDto';


let API_URL = "http://localhost:8080";
@Injectable({
  providedIn: 'root'
})


export class HttpClientDataService {
  submitRule: any;

  constructor(private http: HttpClient) { }


  findAllBooks(): Observable<any> {
    return this.http.get(API_URL + "/books",
  {});
  }
  
  submitAllBooks(books:BooksDto): Observable<any> {
    return this.http.post(API_URL + "/books/save",books
  );
  }
}
