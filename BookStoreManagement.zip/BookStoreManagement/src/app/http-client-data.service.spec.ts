import { TestBed } from '@angular/core/testing';

import { HttpClientDataService } from './http-client-data.service';

describe('HttpClientService', () => {
  let service: HttpClientDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpClientDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
