export class BooksDto {

 id: number | undefined;
    public price: number | undefined;
    public author: string | undefined;
    public bookName: string | undefined;
    public category: string | undefined;
    public edition: string | undefined;
    constructor(){

    }
    // constructor(
    //      id: number,
    //      price: number,
    //      author: string,
    //      bookName: string,
    //      category: string,
    //      edition: string,
    
    // ) { 
    //     this.id=id;
    //     this.author=author;
    //     this.bookName=bookName;
    //     this.category=category;
    //     this.edition=edition;
    //     this.price=price;
    // }

  
}
