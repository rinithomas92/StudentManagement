import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientDataService } from 'src/app/http-client-data.service';
import { BooksDto } from 'src/app/model/BooksDto';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  bookName: any;
  author:any;
  price:any;
  category:any;

  books: BooksDto | undefined;
  edition: string | undefined;
  finalData: any;
  constructor(private httpClientService: HttpClientDataService,
    private router:Router) { }

  ngOnInit(): void {
    console.log
  }


  save(){

    this.books = new BooksDto;
    this.books.id=0;
    this.books.bookName=this.bookName;
    this.books.author=this.author;
    this.books.category=this.category;
    this.books.edition=this.edition;

    if(!this.books.bookName || !this.books.author||!this.books.category||!this.books.edition){
      alert("Please enter details before proceeding");
      return;
       
    }

    this.httpClientService.submitAllBooks(this.books).subscribe(data => {
      this.finalData = data;
      console.log(this.finalData)
      alert("Book registered successfully");
    });
 
    this.router.navigate(['/booklist']);
  
  }
}
