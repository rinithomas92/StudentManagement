import { Component, OnInit } from '@angular/core';
import { HttpClientDataService } from 'src/app/http-client-data.service';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  public bookList:any;

  constructor(private httpClientService: HttpClientDataService) { }

  ngOnInit(): void {
    this.findAllBooks();
  }


  findAllBooks(){
    this.httpClientService.findAllBooks().subscribe(data => {
      this.bookList = data;
    });
  }

}
