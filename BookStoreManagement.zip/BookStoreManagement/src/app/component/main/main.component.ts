import { Component, OnInit } from '@angular/core';
import { HttpClientDataService } from 'src/app/http-client-data.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css'],
  providers: [] 
})
export class MainComponent implements OnInit {


  constructor(private httpClientService: HttpClientDataService) {
  }

  ngOnInit() {
  }



}
