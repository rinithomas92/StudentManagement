import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  canMody:any;

  constructor(public  loginService:AuthenticationService) { }

  ngOnInit(): void {
    var b='1233';
    let a='5';
    console.log(a);
  }

}
